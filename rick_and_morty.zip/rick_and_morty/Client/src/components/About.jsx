const About = () => {
  return (
    <div>
      <h1>Soy el About!!</h1>
    </div>
  );
};

export default About;
